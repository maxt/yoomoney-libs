#import <UIKit/UIKit.h>

//! Project version number for YooMoneyUserAuthCenterApi.
FOUNDATION_EXPORT double YooMoneyUserAuthCenterApiVersionNumber;

//! Project version string for YooMoneyUserAuthCenterApi.
FOUNDATION_EXPORT const unsigned char YooMoneyUserAuthCenterApiVersionString[];