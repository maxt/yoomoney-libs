#import <UIKit/UIKit.h>

//! Project version number for YooMoneyPinning.
FOUNDATION_EXPORT double YooMoneyPinningVersionNumber;

//! Project version string for YooMoneyPinning.
FOUNDATION_EXPORT const unsigned char YooMoneyPinningVersionString[];