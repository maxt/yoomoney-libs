#import <UIKit/UIKit.h>

//! Project version number for YooMoneyAuthenticatorApi.
FOUNDATION_EXPORT double YooMoneyAuthenticatorApiVersionNumber;

//! Project version string for YooMoneyAuthenticatorApi.
FOUNDATION_EXPORT const unsigned char YooMoneyAuthenticatorApiVersionString[];