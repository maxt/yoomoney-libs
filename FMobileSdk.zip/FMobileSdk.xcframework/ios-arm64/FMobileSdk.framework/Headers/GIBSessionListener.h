//
//  GIBSessionListener.h
//  MobileSdk
//
//  Created by Isa Aliev on 02/09/2019.
//  Copyright © 2019 Group-IB. All rights reserved.
//

#ifndef GIBSessionListener_h
#define GIBSessionListener_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// The GIBSessionListener protocol defines the interface to receive the events about changing the state of the Mobile SDK session. An instance of the successor class must be set by calling the setSessionListener method.

typedef NS_ENUM(NSInteger, ConnectionErrorType) {
    ConnectionErrorTypeSessionRequestError = 0,
    ConnectionErrorTypeBadResponseCode = 1,
    ConnectionErrorTypeReadResponseError = 2,
    ConnectionErrorTypeNoInternetConnection = 3,
    ConnectionErrorTypeInvalidJson = 4
};

@protocol GIBSessionListener <NSObject>

/// The sessionDidOpenWithID method is called when the Mobile SDK session is opened - the first value of the cfids cookie received after calling the run method.
/// @param sessionId Identifier of the Mobile SDK session
- (void)sessionDidOpenWithID:(NSString *)sessionId;

- (void)sessionDidGetId:(NSString *)sessionId;

@optional
/// Called right before SDK attempts to send a packet from the queue
/// @param timestampMs milliseconds since 1970 (Unix epoch)
- (void)onPacketReadyToSend:(NSNumber *)timestampMs;

/// Announce when the SDK plans to attempt sending a packet next
/// @param timeoutMs milliseconds until the next attempt (0 means immediately)
- (void)onPacketTimeout:(NSNumber *)timeoutMs;

/// Called when a connection-related error occurred during packet processing
/// @param type One of ConnectionErrorType
/// @param error Underlying NSError if available (can be nil)
/// @param responseCode HTTP status code if available (can be nil)
- (void)onConnectionError:(ConnectionErrorType)type
                    error:(NSError * _Nullable)error
             responseCode:(NSNumber * _Nullable)responseCode;

@end

NS_ASSUME_NONNULL_END

#endif /* GIBSessionListener_h */
